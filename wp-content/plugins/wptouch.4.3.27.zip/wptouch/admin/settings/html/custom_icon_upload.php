<div class="custom-icon-uploader" id="custom_icon_uploader">
	<div class="wpt-spinner" style="opacity: 0"></div>
	<button class="upload button-secondary" id="custom_icon_upload_button"><?php _e( 'Upload Icon', 'wptouch-pro' ); ?></button>
	<div id="custom_icon_uploader_spot" style="display: none;"></div>
</div>