<?php

require_once( 'text.php' );