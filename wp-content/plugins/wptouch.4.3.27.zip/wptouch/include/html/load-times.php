<div id="wptouch-query">
	<?php echo sprintf( __( '%d queries in %0.1f ms', 'wptouch-pro' ), get_num_queries(), 1000*timer_stop( 0, 4 ) ); ?>
</div> 
